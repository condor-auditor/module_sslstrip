/* 
#modulo sslstrip es una herramienta para CONDOR.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 
$(document).ready(function() {


  $('#sslstrip_process_running').on('click', function(e){
    load_list_process();
  });


  $('.validate-numeric').keyup(function (){
    this.value = (this.value + '').replace(/[^0-9]/g, '');
  });


  $('#execute_command').on('click', function(e){
     e.preventDefault();
      var command = $('#command_text').val();

      $('#command_text').val('');
      var accion = "execute";

        $("#loading_command_pid").addClass("progress"); 
        $.ajax({
            method:'POST',
            url:'setting/manage.php',
            data:{accion:accion,command:command},
            success:function(retorno){
                if (retorno == "si") {
                    $("#list_command_pid").empty();
                    load_list_process();
                }

            },
            error: function(){
                alert("ocurrio algo, intenta mas tarde");
            }
        });

    });    

});


$('#report_credential').on('click', function(e){
    var action = "report_credential";
    $("#loading_logs_read").addClass("progress");

    $.ajax({
        method:'POST',
        url:'report/report.php',
        data:{action:action},
        success:function(pdf){
            $("#loading_logs_read").removeClass("progress");
           if (pdf != '') {
             window.open(pdf, '_blank');
           }
        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
        }
    });

});


$('#report_all_log').on('click', function(e){
    var action = "report_all_log";
    $("#loading_logs_read_complete").addClass("progress");

    $.ajax({
        method:'POST',
        url:'report/report.php',
        data:{action:action},
        success:function(pdf){
            window.open(pdf, '_blank');
        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
        }
    });

});


function install_uninstall_sslstrip(){

    var module = 'install_uninstall';
    $.get('setting/'+module+'.php', function(data) {

        for (var line in data)
        {
            var html = '';
            if (data[line].status == 'N.I') {
                html += '<tr>';
                html += '<td class="pink-text">'+data[line].service+'</td>';
                html += '<td class="red-text">not installed</td>';
                html += '<td>'+"<div class='switch'><label><input type='checkbox' id='install "+data[line].service+"'onclick='return manage_sslstrip(this);'><span class='lever'></span></label></div>"+'</td>';
                html += '</tr>';

                $("#list_install_sslstrip").append(html);
                $("#list_install_sslstrip").addClass('animated fadeInLeftBig');
            }else{
                html += '<tr>';
                html += '<td class="pink-text">'+data[line].service+'</td>';
                html += '<td class="green-text">installed</td>';
                html += '<td>'+"<div class='switch'><label><input type='checkbox' checked id='remove "+data[line].service+"'onclick='return manage_sslstrip(this);'><span class='lever'></span></label></div>"+'</td>';
                html += '</tr>';

                $("#list_install_sslstrip").append(html);
                $("#list_install_sslstrip").addClass('animated fadeInLeftBig');
            }
        }

    }, 'json');
}


function status_sslstrip(){
    $("#list_service_sslstrip").empty();
    var module = 'status_sslstrip';

    $.get('setting/'+module+'.php', function(data) {
        for (var line in data)
        {
            var html = '';
            if (data[line].status == 'R'  ) {
                html += '<tr>';
                html += '<td class="pink-text">'+data[line].service+'</td>';
                html += '<td class="green-text">Running</td>';
                html += '</tr>';

                $("#list_service_sslstrip").append(html);
                $("#list_service_sslstrip").addClass('animated fadeInLeftBig');
            }else if(data[line].status == 'N.I'){
                html += '<tr>';
                html += '<td class="pink-text">'+"NOT INSTALLED"+'</td>';
                html += '<td class="pink-text">'+"NOT INSTALLED"+'</td>';
                html += '</tr>';
                $("#list_service_sslstrip").append(html);
                $("#list_service_sslstrip").addClass('animated fadeInLeftBig');
            }else{
                html += '<tr>';
                html += '<td class="pink-text">'+data[line].service+'</td>';
                html += '<td class="red-text">stopped</td>';
                html += '</tr>';

                $("#list_service_sslstrip").append(html);
                $("#list_service_sslstrip").addClass('animated fadeInLeftBig');
            }
        }

    }, 'json');

} 



/* FUNCION PARA CAPTURAR ID DE LOS PROCESOS Y MANEJARLOS */


function manage_sslstrip(item){
 $("#loading_process_sslstrip").addClass("progress"); 
 var id = $(item).attr("id");

 if (id == 'remove sslstrip'){
    var accion = 'remove';
    $.ajax({
        method:'POST',
        url:'setting/manage.php',
        data:{accion:accion},

        success:function(retorno){
            $("#loading_process_sslstrip").removeClass("progress");
            if (retorno == 'removed'){
                $("#list_install_sslstrip").empty();
                $("#list_service_sslstrip").empty();
                alert("sslstrip desinstalado correctamente");
                status_sslstrip();
                install_uninstall_sslstrip();
            }else{
                alert("ocurrio algo mientras se ejecutaba la accion");
            }
        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
            $("#loading_process_sslstrip").removeClass("progress");
        }
    });
}else if(id == 'install sslstrip'){
    var accion = 'install';
    $.ajax({
        method:'POST',
        url:'setting/manage.php',
        data:{accion:accion},

        success:function(retorno){
            $("#loading_process_sslstrip").removeClass("progress");
            if (retorno == 'not internet') {
                alert("verifica tu conexion a internet");

            }else if (retorno == 'installed'){
                $("#list_install_sslstrip").empty();
                $("#list_service_sslstrip").empty();

                alert("sslstrip se instalo correctamente");
                status_sslstrip();
                install_uninstall_sslstrip();
            }else{
                alert("ocurrio algo mientras se ejecutaba la accion");
            }
        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
            $("#loading_process_sslstrip").removeClass("progress");
        }
    });
}

} 

/* FUNCION PARA CAPTURAR ID DE LOS PROCESOS Y MANEJARLOS */


function kill_sslstrip(item){
     var id = $(item).attr("id");
     var accion = 'kill';
     $.ajax({
        method:'POST',
        url:'setting/manage.php',
        data:{pid:id, accion:accion},

        success:function(retorno){
            if (retorno == "si") {
                load_list_process();
            }
        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
        }
     });
}


function list_document(){
 var action = "list_document";
     $.ajax({
        method:'POST',
        url:'report/report.php',
        data:{action:action},

        success:function(data){
            var data = JSON.parse(data);
            $("#list_cant_report").empty();

            if (data == null) {
                var html = '';
                html += '<tr>';
                html += '<td class="pink-text">N.A</td>';
                html += '<td class="green-text">N.A</td>';
                html += '<td class="green-text">N.A</td>';
                html += '<td class="green-text">N.A</td>';
                html += '</tr>';
                $("#loading_report_generate").removeClass("progress");
                $("#list_cant_report").append(html);
                $("#list_cant_report").addClass('animated fadeInLeftBig');
            }else{
                for (var line in data)
                {
                    var html = '';
                    html += '<tr>';
                    html += '<td class="pink-text">'+data[line].cant+'</td>';
                    html += '<td class="green-text">'+data[line].name_pdf+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_pdf+"'onclick='return download_document(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_pdf+"'onclick='return delete_document(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '</tr>';
                    $("#loading_report_generate").removeClass("progress");
                    $("#list_cant_report").append(html);
                    $("#list_cant_report").addClass('animated fadeInLeftBig');
                }
            }
        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
        }
     });
}


function list_compress(){
 var action = "list_compress";
     $.ajax({
        method:'POST',
        url:'report/report.php',
        data:{action:action},

        success:function(data){
            var data = JSON.parse(data);
            $("#list_cant_compress").empty();

            if (data == null) {

                var html = '';
                html += '<tr>';
                html += '<td class="pink-text">N.A</td>';
                html += '<td class="green-text">N.A</td>';
                html += '<td class="green-text">N.A</td>';
                html += '<td class="green-text">N.A</td>';
                html += '</tr>';
                $("#loading_compress_generate").removeClass("progress");
                $("#list_cant_compress").append(html);
                $("#list_cant_compress").addClass('animated fadeInLeftBig');           
            }else{

                for (var line in data)
                {
                    var html = '';
                    html += '<tr>';
                    html += '<td class="pink-text">'+data[line].cant+'</td>';
                    html += '<td class="green-text">'+data[line].name_compress+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_compress+"'onclick='return download_compress(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_compress+"'onclick='return delete_compress(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '</tr>';
                    $("#loading_compress_generate").removeClass("progress");
                    $("#list_cant_compress").append(html);
                    $("#list_cant_compress").addClass('animated fadeInLeftBig');
                }
            }



        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
        }
     });
}

list_document();
list_compress();

$("#list_all_report_generate").on('click', function(e){
    e.preventDefault;
    list_document();

});


$("#list_all_compress").on('click', function(e){
    e.preventDefault;
    list_compress();

});


function download_document(item){
     var id = $(item).attr("id");
     window.open("pdf/"+id, 'Download');
}


function download_compress(item){
     var id = $(item).attr("id");
     window.open("logs/compress/"+id, 'Download');
}



function delete_document(item){
     var id = $(item).attr("id");
     var action = "delete_document";
     $.ajax({
        method:'POST',
        url:'report/report.php',
        data:{documento:id, action:action},

        success:function(data){
            var data = JSON.parse(data);
            $("#list_cant_report").empty();
            for (var line in data)
            {
                var html = '';
                    html += '<tr>';
                    html += '<td class="pink-text">'+data[line].cant+'</td>';
                    html += '<td class="green-text">'+data[line].name_pdf+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_pdf+"'onclick='return download_document(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_pdf+"'onclick='return delete_document(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '</tr>';
                    $("#loading_report_generate").removeClass("progress");
                    $("#list_cant_report").append(html);
                    $("#list_cant_report").addClass('animated fadeInLeftBig');
            }
        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
        }
     });

}

function delete_compress(item){
     var id = $(item).attr("id");
     var action = "delete_compress";
     $.ajax({
        method:'POST',
        url:'report/report.php',
        data:{documento:id, action:action},

        success:function(data){
            var data = JSON.parse(data);
            $("#list_cant_compress").empty();
            for (var line in data)
            {
                var html = '';
                    html += '<tr>';
                    html += '<td class="pink-text">'+data[line].cant+'</td>';
                    html += '<td class="green-text">'+data[line].name_compress+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_compress+"'onclick='return download_compress(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_compress+"'onclick='return delete_compress(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '</tr>';
                    $("#loading_compress_generate").removeClass("progress");
                    $("#list_cant_compress").append(html);
                    $("#list_cant_compress").addClass('animated fadeInLeftBig');
            }
        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
        }
     });

}

    function load_list_process(){
        $("#loading_command_pid").addClass("progress");

        var module = 'monitor_process';
        $.get('setting/'+module+'.php', function(data) {
            $("#list_command_pid").empty();
            status_sslstrip();
            for (var line in data)
            {
                var html = '';
                if (data[line].process == 'N.A') {
                    html += '<tr>';
                    html += '<td class="pink-text">'+data[line].process+'</td>';
                    html += '<td class="pink-text">'+data[line].process+'</td>';
                    html += '<td class="pink-text">'+data[line].process+'</td>';
                    html += '</tr>';

                    $("#loading_command_pid").removeClass("progress");
                    $("#list_command_pid").append(html);
                    $("#list_command_pid").addClass('animated fadeInLeftBig');
                }else{
                    html += '<tr>';
                    html += '<td class="pink-text">'+data[line].process+'</td>';
                    html += '<td class="green-text">'+data[line].pid+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' checked id='"+data[line].pid+"'onclick='return kill_sslstrip(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '</tr>';

                    $("#loading_command_pid").removeClass("progress");
                    $("#list_command_pid").append(html);
                    $("#list_command_pid").addClass('animated fadeInLeftBig');
                }
            }

        }, 'json');
    }


    function read_log(){
        $("#loading_logs_read").addClass("progress");

        var module = 'logs_read';
        $.get('setting/'+module+'.php', function(data) {
            $("#content_report_sslstrip_credential").empty();
            $("#loading_logs_read").removeClass("progress");

            for (var line in data)
            {
                var html = '';
                if (data[line].status == 'NOT LOGS'  ) {
                    html += '<tr>';
                    html += '<td class="pink-text">NOT LOGS</td>';
                    html += '<td class="green-text">NOT LOGS</td>';
                    html += '</tr>';

                    $("#content_report_sslstrip_credential").append(html);
                    $("#content_report_sslstrip_credential").addClass('animated fadeInLeftBig');
                }else{
                    html += '<tr>';
                    html += '<td class="pink-text">'+data[line].data1+'</td>';
                    html += '<td class="purple-text">'+data[line].data2+'</td>';

                    html += '</tr>';

                    $("#content_report_sslstrip_credential").append(html);
                    $("#content_report_sslstrip_credential").addClass('animated fadeInLeftBig');
                }
            }

        }, 'json');
    }


    function read_log_complete(){
        $("#loading_logs_read_complete").addClass("progress");

        var module = 'logs_read_complete';
        $.get('setting/'+module+'.php', function(data) {
            $("#content_report_sslstrip_complete").empty();
            $("#loading_logs_read_complete").removeClass("progress");

            for (var line in data)
            {
                var html = '';
                if (data[line].status == 'NOT LOGS'  ) {
                    html += '<tr>';
                    html += '<td class="pink-text">NOT LOGS</td>';
                    html += '<td class="green-text">NOT LOGS</td>';
                    html += '</tr>';

                    $("#content_report_sslstrip_complete").append(html);
                    $("#content_report_sslstrip_complete").addClass('animated fadeInLeftBig');
                }else{
                    html += '<tr>';
                    html += '<td class="pink-text">'+data[line].hora+'</td>';
                    html += '<td class="pink-text">'+data[line].fecha+'</td>';
                    html += '<td class="blue-text">'+data[line].logs+'</td>';
                    html += '</tr>';

                    $("#content_report_sslstrip_complete").append(html);
                    $("#content_report_sslstrip_complete").addClass('animated fadeInLeftBig');
                }
            }

        }, 'json');
    }

    setInterval(read_log, 60000);
      $('#load_read_logs').on('click', function(e){
            read_log();
        });


    setInterval(read_log_complete, 60000);
      $('#load_read_logs_complete').on('click', function(e){
            read_log_complete();
        });



status_sslstrip();
install_uninstall_sslstrip();
load_list_process();
$('.modal').modal();
