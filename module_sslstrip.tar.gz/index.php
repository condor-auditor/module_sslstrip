<?php 
/* 
#modulo sslstrip es una herramienta para CONDOR.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 
include_once("../../system/menu.php");
include_once("__init__.php");

?>

<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,maximun-scale=1,user-scalable=no">
	<title></title>
	<link href="" rel="shortcut icon">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link type="text/css" rel="stylesheet" href="<?php echo BASE ?>css/materialize.css">
	<link type="text/css" rel="stylesheet" href="<?php echo BASE ?>css/estilos.css">
	<link rel="stylesheet" type="text/css" href="<?php echo BASE ?>css/animate.css">
</head>
<body>

    <div class="row">
      <div class="col l12 s12 m12" id="update_modal">
         <div class="indeterminate"></div>
      </div>
    </div>

	<div class="row">
		<div class="col l12 s12 m12 card hoverable grey lighten-3">
			<div class="card">
				<div class="card-content purple card-title"><h5 class=" center-align  white-text "><?php echo __('SSLSTRIP',$lang) ?> | v<?php echo $module_version?></h5></div>
				<div class="row">
					<nav class="nav-extended">
						<div class="nav-wrapper">
							<ul class="tabs tabs-transparent purple accent-3">
								<li class="tab"><a class="active" href="#manage"><?php echo __('MANAGE',$lang) ?></a></li>
								<li class="tab"><a href="#status"><?php echo __('STATUS',$lang) ?></a></li>
								<li class="tab"><a href="#logs"><?php echo __('LOGS',$lang) ?></a></li>
								<li class="tab"><a href="#install"><?php echo __('INSTALL',$lang) ?></a></li>
								<li class="tab"><a href="#list_report"><?php echo __('LIST REPORT',$lang) ?></a></li>
								<li class="tab"><a href="#list_compress"><?php echo __('LIST COMPRESS',$lang) ?></a></li>
								<li class="tab"><a href="#about"><?php echo __('ABOUT',$lang) ?></a></li>
							</ul>
						</div>
					</nav>

					<div id="manage" class="col l12  s12 m12">
						<div class="row">
							<div class="card hoverable col l3 m12 s12">
								<form method="post">
									<div class="row">
										<div class="input-field col s12">
											<input id="command_text" type="number" class="validate validate-numeric">
											<label for="command" data-error="campo obligatorio" data-success="listo"><?php echo __('Listening port , default 10000',$lang) ?></label>
										</div>
									</div>
								</form>
								<div class="row">
									<div class="col l12 offset-l3 s12 offset-s4 m12 offset-m5 " id="execute_command"><a class="waves-effect waves-light btn"><i class="material-icons left">done</i><?php echo __('send',$lang) ?></a></div>
								</div>
							</div>
							<div class="col l9 s12 m12">
								<!-- CAJA PARA MONITOR STATION OF WORK -->
								<div class="col l12 s12 m12 card hoverable grey lighten-3">
									<div class="card">
										<div class="card-content brown accent-3 card-title"><h5 class=" center-align  white-text "><?php echo __('SERVICE PID RUNNING',$lang) ?><div><a id="sslstrip_process_running" style="cursor:pointer"><i class="small material-icons">loop</i></a></div></h5></div>
										<div class="row">
											<div class="col l12 s12 m12  scrollbar scrollbar-elegante">
												<div id="loading_command_pid">
													<div class="indeterminate"></div>
												</div>
												<table class="responsive-table highlight bordered centered">
													<thead>
														<tr>
															<th data-field="interface"><?php echo __('COMMAND',$lang) ?></th>
															<th data-field="ip"><?php echo __('PID',$lang) ?></th>
															<th data-field="ip"><?php echo __('KILL',$lang) ?></th>
														</tr>
													</thead>

													<tbody id="list_command_pid">
													</tbody>
												</table>

											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div id="status" class="col l12 s12 m12">
						<div class="card">
							<!-- CAJA PARA STATUS SERVICE-->
							<div class="card-content orange accent-3 card-title"><h5 class=" center-align  white-text "><?php echo __('SERVICE STATUS',$lang) ?></h5></div>
							<div class="row">
								<div class="col l12 s12 m12">
									<table class="responsive-table highlight bordered centered">
										<thead>
											<tr>
												<th data-field="model"><?php echo __('Service Name',$lang) ?></th>
												<th data-field="cores"><?php echo __('Status service',$lang) ?></th>
											</tr>
										</thead>
										<tbody id="list_service_sslstrip">
										</tbody>
									</table>
								</div> 
							</div> 
						</div>
					</div>


					<div id="logs" class="col s12">
						<div class="card">
							<!-- CAJA PARA STATUS LOGS-->
							<div class="card-content orange accent-3 card-title"><h5 class=" center-align  white-text "><?php echo __('LOGS',$lang) ?><div><a id="load_read_logs" style="cursor:pointer"><i class="small material-icons">loop</i></a><a id="report_credential" style="cursor:pointer"><i class="small material-icons black-text">picture_as_pdf</i></a></div></h5></div>
							<div class="row">
								<div class="col l12 s12 m12">
									<div id="loading_logs_read">
										<div class="indeterminate"></div>
									</div>
									<div class="col l12 s12 m12 scrollbar scrollbar-elegante">
										<table class="responsive-table highlight bordered centered">
											<thead>
												<tr>
													<th data-field="model"><?php echo __('DATA',$lang) ?></th>
													<th data-field="model"><?php echo __('CREDENTIAL',$lang) ?></th>
												</tr>
											</thead>
											<tbody id="content_report_sslstrip_credential">
											</tbody>
										</table>
									</div>
								</div> 
							</div> 
						</div>

						<div class="card">
							<!-- CAJA PARA STATUS LOGS-->
							<div class="card-content green darken-3 card-title"><h5 class=" center-align  white-text "><?php echo __('LOGS CAPTURE COOKIE AND SESSION',$lang) ?><div><a id="load_read_logs_complete" style="cursor:pointer"><i class="small material-icons">loop</i></a><a id="report_all_log" style="cursor:pointer"><i class="small material-icons black-text">picture_as_pdf</i></a></div></h5></div>
							<div class="row">
								<div class="col l12 s12 m12">
									<div id="loading_logs_read_complete">
										<div class="indeterminate"></div>
									</div>
									<div class="col l12 s12 m12 scrollbar scrollbar-elegante">
										<table class="responsive-table highlight bordered centered">
											<thead>
												<tr>
													<th data-field="model"><?php echo __('HOUR',$lang) ?></th>
													<th data-field="model"><?php echo __('DATE',$lang) ?></th>
													<th data-field="cores"><?php echo __('LOGS',$lang) ?></th>
												</tr>
											</thead>
											<tbody id="content_report_sslstrip_complete">
											</tbody>
										</table>
									</div>
								</div> 
							</div> 
						</div>
					</div>

					<div id="install" class="col s12">
						<div class="card">
							<!-- CAJA PARA INSTALL SERVICE-->
							<div class="col l12 s12 m12">
								<div class="card-content  orange accent-3 card-title"><h5 class=" center-align  white-text "><?php echo __('INSTALL SERVICE',$lang) ?></h5></div>
								<div class="row">
									<div class="col l12 s12 m12">
										<div id="loading_process_sslstrip">
											<div class="indeterminate"></div>
										</div>
										<table class="responsive-table highlight bordered centered">
											<thead>
												<tr>
													<th data-field="model"><?php echo __('Service Name',$lang) ?></th>
													<th data-field="cores"><?php echo __('Status service',$lang) ?></th>
													<th data-field="speed"><?php echo __('install/unistall',$lang) ?></th>
												</tr>
											</thead>
											<tbody id="list_install_sslstrip">
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="list_report" class="col s12">
						<div class="card">
							<!-- CAJA PARA LIST REPORT-->
							<div class="col l12 s12 m12">
								<div class="card-content blue card-title"><h5 class=" center-align  white-text "><?php echo __('LIST REPORT',$lang) ?><div><a id="list_all_report_generate" style="cursor:pointer"><i class="small material-icons orange-text">loop</i></a></div></h5></div>
								<div class="row">
									<div class="col l12 s12 m12 scrollbar scrollbar-elegante">
										<div id="loading_report_generate">
											<div class="indeterminate"></div>
										</div>
										<table class="responsive-table highlight bordered centered">
											<thead>
												<tr>
													<th data-field="model"><?php echo __('Nº',$lang) ?></th>
													<th data-field="cores"><?php echo __('NAME',$lang) ?></th>
													<th data-field="speed"><?php echo __('DOWNLOAD',$lang) ?></th>
													<th data-field="speed"><?php echo __('DELETE',$lang) ?></th>
												</tr>
											</thead>
											<tbody id="list_cant_report">
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="list_compress" class="col s12">
						<div class="card">
							<!-- CAJA PARA LIST REPORT-->
							<div class="col l12 s12 m12">
								<div class="card-content red card-title"><h5 class=" center-align  white-text "><?php echo __('LIST COMPRESS',$lang) ?><div><a id="list_all_compress" style="cursor:pointer"><i class="small material-icons orange-text">loop</i></a></div></h5></div>
								<div class="row">
									<div class="col l12 s12 m12 scrollbar scrollbar-elegante">
										<div id="loading_compress_generate">
											<div class="indeterminate"></div>
										</div>
										<table class="responsive-table highlight bordered centered">
											<thead>
												<tr>
													<th data-field="model"><?php echo __('Nº',$lang) ?></th>
													<th data-field="cores"><?php echo __('NAME',$lang) ?></th>
													<th data-field="speed"><?php echo __('DOWNLOAD',$lang) ?></th>
													<th data-field="speed"><?php echo __('DELETE',$lang) ?></th>
												</tr>
											</thead>
											<tbody id="list_cant_compress">
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="about" class="col l12 s12 m12">
						<div class="row">
							<div class="col l7 s12 m12 card hoverable">
								<h5 class="black-text"><?php echo __('Module Name',$lang) ?>:<a class="green-text"><?php echo " ".$module_name?></a></h5>
								<h5 class="black-text"><?php echo __('Module Version',$lang) ?>:<a class="green-text"><?php echo " ".$module_version?></a></h5>
								<h5 class="black-text"><?php echo __('Module Author',$lang) ?>:<a target="_blank" href="http://twitter.com/sasaga92"><?php echo " ".$module_author?></a></h5>
								<h5 class="black-text"><?php echo __('Module Contact',$lang) ?>:<a class="green-text"><?php echo " ".$module_contact?></a></h5>
								<h5 class="black-text" align="justify"><?php echo __('Module Description',$lang) ?>:<a class="green-text"><?php echo " ".$module_description?></a></h5>
								
							</div>
							<div class="col l5 s12 m12 card hoverable" style="word-wrap: break-word">
								<div class="video-container">
									<iframe width="853" height="480" src="<?php echo $link_tutorial_sslstrip ?>" frameborder="0" allowfullscreen></iframe>
								</div>
								<h5 class="black-text"><?php echo __('Page Official',$lang) ?>:<a target="_blank" href="<?php echo $link_pag_oficial_sslstrip?>" ><?php echo " ".$link_pag_oficial_sslstrip?></a></h5>
								<h5 class="black-text"><?php echo __('Download project',$lang) ?>:<a target="_blank" href="<?php echo $link_dowload_project?>" ><?php echo " ".$link_dowload_project?></a></h5>

							</div>
						</div>
					</div>
				</div>
			</div>
			<script src="<?php echo BASE ?>js/jquery-3.1.1.min.js" type="text/jscript"></script>
			<script src="<?php echo BASE ?>js/materialize.js" type="text/javascript"></script>
			<script src="<?php echo $path_base ?>/js/process.js" type="text/javascript"></script>
			<script src="<?php echo $path_base ?>/js/update.js" type="text/javascript"></script>
		</body>

		</html>
