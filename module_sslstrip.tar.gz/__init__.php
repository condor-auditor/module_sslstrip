<?php 
/* 
#modulo sslstrip es una herramienta para CONDOR.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 
$module_name="module_sslstrip";
$path_bin_sslstrip = "sslstrip";
$module_version = "1.0"; 
$module_version_software  ="https://raw.githubusercontent.com/condor-auditor/".$module_name."/master/version";
$path_module_dowload = "https://github.com/condor-auditor/".$module_name.".git";

$module_author = "@sasaga92";
$module_contact = "ssanchezga@ufpso.edu.co";
$path_module_sslstrip = "/usr/share/lighttpd/condor/www/modules/".$module_name;
$path_log_directory_sslstrip = $path_module_sslstrip."/logs/";
$path_log_directory_compress_sslstrip = $path_log_directory_sslstrip."compress";
$path_log_sslstrip = $path_module_sslstrip."/logs/sslstrip.log";
$path_log_parseado = $path_module_sslstrip."/logs/parseado.txt";
$path_log_parseado_complete = $path_module_sslstrip."/logs/parseado_complete.txt";
$path_log_sslstrip_command_pid = $path_module_sslstrip."/logs/command_pid.log";
$path_log_service_running = "/usr/share/lighttpd/condor/logs/SERVICES_RUNNING";
$path_ip_forward = "/proc/sys/net/ipv4/ip_forward";
$path_base = BASE."/modules/".$module_name;
$path_script_parser = $path_module_sslstrip."/logs/parser/parser.sh";
$path_script_parser_complete = $path_module_sslstrip."/logs/parser_complete/parser.sh";
$path_list_parser = $path_module_sslstrip."/logs/parser/list_parser.txt";
$module_description = " SSLSTrip es una aplicación para sistemas operativos Linux capaz de “descifrar todo el tráfico HTTPS” que viaja a través de la red y sniffar el tráfico (usuarios y claves) que viaja a través de la red en “HTTPS (cifrado)”. ";
$path_binary_module = "module_sslstrip.tar.gz.gpg";
$name_compress_module = "module_sslstrip.tar.gz";
$link_pag_oficial_sslstrip = "https://moxie.org/software/sslstrip/";
$link_tutorial_sslstrip = "https://www.youtube.com/embed/0rrN-znx9h0";
$link_dowload_project = "https://moxie.org/software/sslstrip/sslstrip-0.9.tar.gz";
?>
