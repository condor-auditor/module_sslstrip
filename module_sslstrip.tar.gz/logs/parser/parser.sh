#!/bin/bash
 
#modulo sslstrip es una herramienta para CONDOR.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.


cat $1 |
awk -F "(" '/POST Data/ {for (i=1;i<=NF;i++) if (match($i,/POST Data/)) n=i; print "Website="$2; getline; print $n"\n"}' |
   awk -F "&" '{for(i=1;i<=NF;i++) print $i }' |
   egrep -i -a -f $2 |
   awk -F "=" '{if (length($2) < 4) print "";
   else if ($1 ~/Website/) print $0;
   else if ($1 ~/[Pp]/) print "Password="$2"\n";
   else print "Login="$2}' | 
   uniq 
