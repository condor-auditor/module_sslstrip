#!/bin/bash

awk '/Set-Cookie/;/Sending Request:/; /Sending headers/;/server header/;/sesion/;/Sesion/;/cookie/ {print $0}' $1  | shuf -n 30




