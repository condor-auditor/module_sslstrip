<?php 
/* 
#modulo sslstrip es una herramienta para CONDOR.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 
include_once("../../../system/login_check.php");
include_once("../../../tools/execute/exec.php");
include_once("../__init__.php");


    $services_running = filesize($path_log_sslstrip);


    if ($services_running < 0) {
    	$contente_log[] = array(
    		'status' => 'NOT LOGS'
    	);
        echo json_encode($contente_log);
        exit();
    }elseif ($services_running > 5242880 ) {
        if (!file_exists($path_log_directory_compress_sslstrip)) {
            exec_condor("mkdir $path_log_directory_compress_sslstrip");
        }
        $hoy = date("Y-m-d-H:i:s");
        $ext = $hoy.".tar.gz";
        exec_condor("tar -czf ".$path_log_directory_sslstrip."sslstrip_$ext ".$path_log_sslstrip."");
        exec_condor("tar -czf ".$path_log_directory_sslstrip."parseado_$ext ".$path_log_parseado."");
        exec_condor("cp -rv $path_log_directory_sslstrip*.tar.gz $path_log_directory_compress_sslstrip");
        exec_condor("rm -rf $path_log_directory_sslstrip*.tar.gz");
        exec_condor("cat /dev/null > ".$path_log_sslstrip."");
        exec_condor("cat /dev/null > ".$path_log_parseado."");

    }


    exec_condor("sh -c '$path_script_parser $path_log_sslstrip $path_list_parser > $path_log_parseado'");
    exec("grep . $path_log_parseado",$logs_parsed);

    if (empty($logs_parsed)) {
        $contente_log[] = array(
            'status' => 'NOT LOGS'
            );
        echo json_encode($contente_log);
        exit();
    }

    foreach ($logs_parsed as $line) {
        $separed = explode("=", $line);
            $list[] = array(
                'data1' => $separed[0],
                'data2' => $separed[1]
            );  
    }

	$data = array_reverse($list);
	sleep(3);
    echo utf8_encode(json_encode($data));

?>