<?php 
/* 
#modulo sslstrip es una herramienta para CONDOR.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 
include_once("../../../system/login_check.php");
include_once("../../../tools/execute/exec.php");
include_once("../__init__.php");


    exec_condor("sh -c '$path_script_parser_complete $path_log_sslstrip > $path_log_parseado_complete'");

    $logs_parsed = file($path_log_parseado_complete);

    if (empty($logs_parsed)) {
        $contente_log[] = array(
            'status' => 'NOT LOGS'
            );
        echo json_encode($contente_log);
        exit();
    }

    foreach($logs_parsed as $service){
        $list = explode(": ", $service);
        foreach ($list as $key => $value) {
            $fecha = explode(',',$list[0]);
            $hora = explode(" ", $fecha[0]);
            $report[] = array(
                'hora' => $hora[1],
                'fecha' => $hora[0],
                'logs' => $fecha[1].$list[1].$list[2],
                'status' => 1
                 );
        }

    }

    //exit();
	$data = array_reverse($report);
	sleep(3);
    echo utf8_encode(json_encode($data));

?>
