<?php 
/* 
#modulo sslstrip es una herramienta para CONDOR.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 
include_once("../../../system/login_check.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	include_once("../../../tools/execute/exec.php");
	include_once("../__init__.php");


	
  	$accion = strip_tags(trim(filter_input(INPUT_POST,'accion', FILTER_SANITIZE_STRING)));
  	$command = strip_tags(trim(filter_input(INPUT_POST,'command', FILTER_SANITIZE_STRING)));
  	$pid_kill = strip_tags(trim(filter_input(INPUT_POST,'pid', FILTER_SANITIZE_STRING)));

  	if ($accion != '' && $accion != null && $accion == "remove") {
  		exec_condor("apt --purge remove  $path_bin_sslstrip -y");

  		$query = " sh -c 'if ! hash $path_bin_sslstrip 2>/dev/null; then echo \"no\" ; fi'";
		$salida = exec_condor($query);

	    if (!empty($salida)) {
		   echo "removed";
		}else{
			echo "no";
		}   	
  	}elseif($accion != '' && $accion != null && $accion == "install"){
  		$external_ip = exec("curl ident.me");
        if ($external_ip != "" ) { 
	  		exec_condor("apt install  $path_bin_sslstrip -y");

	  		$query = " sh -c 'if ! hash $path_bin_sslstrip 2>/dev/null; then echo \"no\" ; fi'";
			$salida = exec_condor($query);
		    if (empty($salida)) {
			   echo "installed";
			}else{
				echo "no";
			}  
        }else{
        	echo "not internet";
        }
  	}elseif($accion != '' && $accion != null && $accion == "execute"){
  		if ($command == "") {
  			$port = 10000;
  		}else{
  			$port=$command;
  		}
        $config_ip_forward = "sh -c 'echo 1 > $path_ip_forward'";
        exec_condor($config_ip_forward);

  		$command ="/usr/bin/python /usr/bin/sslstrip  -a -w $path_log_sslstrip  -l $port";
	    exec_condor("sh -c '$command > $path_log_sslstrip &'");

    	$pid = exec_condor("ps -ef | grep \"sslstrip\" | grep -v \"grep\" | awk '{print $2}'");

	    if (!empty($pid)) {
	    	exec_condor("sh -c 'echo \"\nsslstrip\" >> $path_log_service_running'");
	    	exec_condor("sh -c 'echo \"$command\"_*_\"$pid\" >> $path_log_sslstrip_command_pid'");
			exec_condor("sed -i -e '/_*_/!d' $path_log_sslstrip_command_pid");
			echo "si";
    	}else{
	      $status_service[] = array(
           	'command' => 'N.A',
           	'pid' => 'N.A'
           );
	      echo json_encode($status_service);
	      exit();
	    }

  	}elseif($accion != '' && $accion != null && $accion == "kill"){
  		exec_condor("kill -9 ".$pid_kill);
  		exec_condor("sed -i '/$pid_kill/ d' $path_log_sslstrip_command_pid"); 
  		echo "si";
  	}else{
  		echo "no";
  	}
}
?>